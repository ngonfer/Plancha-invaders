import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;

/**
 * Write a description of class Rayo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rayo extends ActorExtension
{
    /**
     * Act - do whatever the Rayo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Rayo()
    {
        velocidad=3f;
        factor = 1/32f;
        Imagen = new GreenfootImage("image.png");
        ScaleBy(factor);
        setImage(Imagen);
    }
    
    public void act()
    {
        // Add your action code here.
        SerDisparado();
    }
        
    public void SerDisparado()
    {
                
        BetterMove((int)(2*velocidad),0);
            
            Actor actor = getOneIntersectingObject(Actor.class);
            if (actor != null) 
            {
                getWorld().removeObject(actor);
                getWorld().removeObject(this);
                Random ran = new Random();
                if (ran.NextInt(2)==1)
                {
                    
                }
                return;
            }
            if (isAtEdge())
            {
                getWorld().removeObject(this);
            }
    }
}
